import koaMongoDb from 'koa-mongo-db';

export default (app)=>{app.use(koaMongoDb('mongodb://localhost/helpcomp'))}