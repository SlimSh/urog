import errors from './errors';
import logger from './logger';
import bodyParser from './bodyParser';
import favicon from './favicon';
import session from './session';
import statics from './static';
import db from './db';

export default [errors, logger, bodyParser, favicon, session, statics, db];