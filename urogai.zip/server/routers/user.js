export default (router)=>{    
    router.get('/user', async (ctx,body) => {
        // console.log();
        await ctx.db.collection('ys').insert({email:'dslimgh@fds.ru'});
        let result = await ctx.db.collection('ys').find().toArray();
        await ctx.db.collection('ys').remove({email:'dslimgh@fds.ru'});

        // console.log(await ctx.db.collection('ys').find().toArray());
        ctx.body = result;
      } )
    }